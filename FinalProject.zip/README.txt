Project by Kalvin Janik, Heather Sheridan, CJ Sloat, Matthew Carlson
A and D to move left and right. Space to jump. Click to shoot.
We each tried taking on the various elements of the AI including the boss's states, movement, attack choices, and the flocking of the minions.